# Example datasets 

The example dataset is a part of Adult Dataset from UCI Machine Learning repository [Link](https://archive.ics.uci.edu/ml/datasets/adult). To have a quick start, the example dataset only contains 200 rows and 15 columns in a tabular data format in a csv file. The RDF file is based on the tabular data. 